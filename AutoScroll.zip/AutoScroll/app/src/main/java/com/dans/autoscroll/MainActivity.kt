package com.dans.autoscroll

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = (24 * resources.displayMetrics.density).toInt()
        val l = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(p, p, p, p)
        }
        l.addView(TextView(this).apply {
            textSize = 16f
            text = "1. Tekan tombol di bawah.\n2. Pilih AutoScroll → aktifkan.\n" +
                "3. Panel melayang akan muncul di semua aplikasi.\n\n" +
                "Untuk mematikan: nonaktifkan lagi di Aksesibilitas."
        })
        l.addView(Button(this).apply {
            text = "Buka Pengaturan Aksesibilitas"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        setContentView(l)
    }
}

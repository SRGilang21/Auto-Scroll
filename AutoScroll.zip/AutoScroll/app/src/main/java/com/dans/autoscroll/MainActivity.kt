package com.dans.autoscroll

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var sw: Switch
    private var updating = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = (24 * resources.displayMetrics.density).toInt()
        val l = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(p, p, p, p)
        }
        status = TextView(this).apply { textSize = 16f; setPadding(0, 0, 0, p / 2) }
        sw = Switch(this).apply {
            text = "Overlay ON / OFF   "
            textSize = 18f
            setPadding(0, p / 2, 0, p / 2)
        }
        sw.setOnCheckedChangeListener { _, on ->
            if (updating) return@setOnCheckedChangeListener
            val s = AutoService.instance
            if (s != null) s.setOverlayVisible(on)
            else getSharedPreferences("cfg", MODE_PRIVATE).edit().putBoolean("visible", on).apply()
        }
        val hint = TextView(this).apply {
            textSize = 14f
            setPadding(0, p / 2, 0, p / 2)
            text = "Aksesibilitas cukup diaktifkan sekali. Setelah itu, nyalakan/matikan overlay " +
                "dari saklar di atas, tanpa perlu menonaktifkan aksesibilitas."
        }
        val btn = Button(this).apply {
            text = "Buka Pengaturan Aksesibilitas"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        l.addView(status); l.addView(sw); l.addView(hint); l.addView(btn)
        setContentView(l)
    }

    override fun onResume() {
        super.onResume()
        val s = AutoService.instance
        updating = true
        sw.isEnabled = s != null
        sw.isChecked = s != null &&
            getSharedPreferences("cfg", MODE_PRIVATE).getBoolean("visible", true)
        updating = false
        status.text = if (s != null) "Aksesibilitas: AKTIF ✔"
        else "Aksesibilitas: belum aktif.\nAktifkan dulu lewat tombol di bawah."
    }
}

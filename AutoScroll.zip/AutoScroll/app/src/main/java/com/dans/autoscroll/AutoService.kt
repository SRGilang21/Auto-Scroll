package com.dans.autoscroll

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as LP
import android.view.accessibility.AccessibilityEvent
import android.widget.*
import kotlin.math.abs

class AutoService : AccessibilityService() {

    private val h = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var panel: LinearLayout
    private val panelLp by lazy {
        LP(WRAP_CONTENT, WRAP_CONTENT, LP.TYPE_ACCESSIBILITY_OVERLAY,
            LP.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(120)
        }
    }
    private val markers = mutableListOf<TextView>()
    private lateinit var speedLabel: TextView
    private lateinit var delayLabel: TextView
    private lateinit var speedBar: SeekBar
    private lateinit var modeBtn: Button
    private lateinit var clickBtn: Button

    // state
    private var speed = 5            // 1..10
    private var delayMs = 1000L
    private var multi = false
    private var scrollDir = 0        // 1 = turun, -1 = naik, 0 = berhenti
    private var loopActive = false
    private var stroke: GestureDescription.StrokeDescription? = null
    private var fingerY = 0f
    private var clicking = false
    private var clickIdx = 0

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildPanel()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        stopScroll(); stopClick()
        h.removeCallbacksAndMessages(null)
        markers.forEach { runCatching { wm.removeView(it) } }
        if (::panel.isInitialized) runCatching { wm.removeView(panel) }
        super.onDestroy()
    }

    // ---------------- UI ----------------

    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; textSize = 12f; isAllCaps = false
        minHeight = 0; minimumHeight = 0; minWidth = 0; minimumWidth = 0
        setPadding(dp(4), dp(6), dp(4), dp(6))
        layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
        setOnClickListener { f() }
    }

    private fun holdBtn(t: String, dir: Int) = btn(t) {}.apply {
        setOnClickListener(null)
        setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> startScroll(dir)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> stopScroll()
            }
            true
        }
    }

    private fun row(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        v.forEach { addView(it) }
    }

    private fun label(t: String) = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = 12f
        setPadding(dp(4), dp(6), dp(4), dp(2))
    }

    private fun buildPanel() {
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            minimumWidth = dp(240)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = GradientDrawable().apply {
                setColor(0xE6202124.toInt()); cornerRadius = dp(12).toFloat()
            }
        }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val header = TextView(this).apply {
            text = "≡ AutoScroll  (tap = lipat, geser = pindah)"
            setTextColor(Color.WHITE); textSize = 12f
            setPadding(dp(4), dp(4), dp(4), dp(6))
        }
        drag(header, panel, panelLp) {
            body.visibility = if (body.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            wm.updateViewLayout(panel, panelLp)
        }

        // --- Scroll ---
        body.addView(label("SCROLL"))
        body.addView(row(
            btn("▲ Naik") { toggleScroll(-1) },
            btn("■ Stop") { stopScroll() },
            btn("▼ Turun") { toggleScroll(1) }
        ))
        speedLabel = label("Kecepatan: $speed")
        speedBar = SeekBar(this).apply {
            max = 9; progress = speed - 1
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { setSpeed(p + 1) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        body.addView(row(btn("🐢 Pelan") { setSpeed(2) }, btn("🐇 Cepat") { setSpeed(9) }))
        body.addView(speedLabel)
        body.addView(speedBar)
        body.addView(label("Tahan untuk scroll:"))
        body.addView(row(holdBtn("Tahan ▲", -1), holdBtn("Tahan ▼", 1)))

        // --- Klik ---
        body.addView(label("AUTO KLIK"))
        modeBtn = btn("Mode: Single") {
            multi = !multi
            modeBtn.text = if (multi) "Mode: Multi" else "Mode: Single"
        }
        body.addView(row(modeBtn))
        body.addView(row(btn("+ Titik") { addMarker() }, btn("− Titik") { removeMarker() }))
        delayLabel = label("Jeda: $delayMs ms")
        body.addView(delayLabel)
        body.addView(row(btn("− Jeda") { stepDelay(false) }, btn("+ Jeda") { stepDelay(true) }))
        clickBtn = btn("▶ Mulai Klik") { if (clicking) stopClick() else startClick() }
        body.addView(row(clickBtn))

        panel.addView(header)
        panel.addView(body)
        wm.addView(panel, panelLp)
    }

    private fun drag(handle: View, target: View, lp: LP, onTap: (() -> Unit)? = null) {
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val ox = (e.rawX - dx).toInt(); val oy = (e.rawY - dy).toInt()
                    if (abs(ox) > 10 || abs(oy) > 10) moved = true
                    lp.x = sx + ox; lp.y = sy + oy
                    wm.updateViewLayout(target, lp)
                }
                MotionEvent.ACTION_UP -> if (!moved) onTap?.invoke()
            }
            true
        }
    }

    // ---------------- Scroll ----------------

    private fun setSpeed(s: Int) {
        speed = s.coerceIn(1, 10)
        speedLabel.text = "Kecepatan: $speed"
        if (speedBar.progress != speed - 1) speedBar.progress = speed - 1
    }

    private fun toggleScroll(dir: Int) { if (scrollDir == dir) stopScroll() else startScroll(dir) }

    private fun startScroll(dir: Int) {
        scrollDir = dir
        if (!loopActive) { loopActive = true; scrollStep() }
    }

    private fun stopScroll() { scrollDir = 0 }

    /** Satu sentuhan jari yang terus bergerak (tanpa diangkat) = scroll halus tanpa fling. */
    private fun scrollStep() {
        if (scrollDir == 0 && stroke == null) { loopActive = false; return }
        val dm = resources.displayMetrics
        val top = dm.heightPixels * 0.2f
        val bottom = dm.heightPixels * 0.8f
        // hindari panel: swipe di sisi layar yang berlawanan dengan panel
        val panelCx = panelLp.x + (if (panel.width > 0) panel.width else dp(240)) / 2
        val x = if (panelCx < dm.widthPixels / 2) dm.widthPixels * 0.85f else dm.widthPixels * 0.15f
        val move = speed * 24f * (if (scrollDir > 0) -1 else 1)  // jari naik = konten turun
        val prev = stroke
        val path = Path()
        val next: GestureDescription.StrokeDescription
        var end = false
        if (prev == null) {
            fingerY = if (scrollDir > 0) bottom else top
            path.moveTo(x, fingerY); path.lineTo(x, fingerY + move)
            fingerY += move
            next = GestureDescription.StrokeDescription(path, 0, 200, true)
        } else {
            path.moveTo(x, fingerY)
            if (scrollDir == 0 || fingerY + move !in top..bottom) {
                path.lineTo(x, fingerY + 1); end = true
                next = prev.continueStroke(path, 0, 10, false)
            } else {
                path.lineTo(x, fingerY + move); fingerY += move
                next = prev.continueStroke(path, 0, 200, true)
            }
        }
        stroke = if (end) null else next
        dispatchGesture(GestureDescription.Builder().addStroke(next).build(),
            object : GestureResultCallback() {
                override fun onCompleted(g: GestureDescription?) { scrollStep() }
                override fun onCancelled(g: GestureDescription?) {
                    stroke = null
                    h.postDelayed({ scrollStep() }, 100)
                }
            }, null)
    }

    // ---------------- Auto klik ----------------

    private fun addMarker() {
        val dm = resources.displayMetrics
        val tv = TextView(this).apply {
            text = "${markers.size + 1}"; gravity = Gravity.CENTER
            setTextColor(Color.WHITE); textSize = 14f
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL; setColor(0xB3E53935.toInt()); setStroke(dp(2), Color.WHITE)
            }
        }
        val lp = LP(dp(44), dp(44), LP.TYPE_ACCESSIBILITY_OVERLAY,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dm.widthPixels / 2 - dp(22) + markers.size * dp(12)
            y = dm.heightPixels / 2 + markers.size * dp(12)
        }
        tv.tag = lp
        drag(tv, tv, lp)
        wm.addView(tv, lp)
        markers.add(tv)
    }

    private fun removeMarker() {
        if (clicking) return
        markers.removeLastOrNull()?.let { runCatching { wm.removeView(it) } }
    }

    private fun setMarkersTouchable(touchable: Boolean) {
        markers.forEach {
            val lp = it.tag as LP
            lp.flags = if (touchable) lp.flags and LP.FLAG_NOT_TOUCHABLE.inv()
                       else lp.flags or LP.FLAG_NOT_TOUCHABLE
            wm.updateViewLayout(it, lp)
        }
    }

    private fun stepDelay(up: Boolean) {
        val s = if (delayMs < 1000) 100L else 500L
        delayMs = (if (up) delayMs + s else delayMs - s).coerceIn(50L, 60000L)
        delayLabel.text = "Jeda: $delayMs ms"
    }

    private val clickRunnable = object : Runnable {
        override fun run() {
            if (!clicking || markers.isEmpty()) { stopClick(); return }
            val m = if (multi) markers[clickIdx % markers.size] else markers[0]
            clickIdx++
            val loc = IntArray(2)
            m.getLocationOnScreen(loc)
            val p = Path().apply { moveTo(loc[0] + m.width / 2f, loc[1] + m.height / 2f) }
            dispatchGesture(GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(p, 0, 50)).build(), null, null)
            h.postDelayed(this, delayMs)
        }
    }

    private fun startClick() {
        if (markers.isEmpty()) {
            Toast.makeText(this, "Tekan '+ Titik' dulu, geser ke target", Toast.LENGTH_SHORT).show()
            return
        }
        clicking = true; clickIdx = 0
        clickBtn.text = "■ Stop Klik"
        setMarkersTouchable(false)
        h.post(clickRunnable)
    }

    private fun stopClick() {
        if (!clicking) return
        clicking = false
        h.removeCallbacks(clickRunnable)
        if (::clickBtn.isInitialized) clickBtn.text = "▶ Mulai Klik"
        setMarkersTouchable(true)
    }
}

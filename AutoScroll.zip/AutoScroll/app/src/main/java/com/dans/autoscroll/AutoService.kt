package com.dans.autoscroll

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as LP
import android.view.accessibility.AccessibilityEvent
import android.widget.*
import kotlin.math.abs

/** ScrollView dengan tinggi maksimum agar menu tidak keluar layar. */
class MaxHeightScroll(c: Context, private val maxH: Int) : ScrollView(c) {
    override fun onMeasure(w: Int, h: Int) {
        super.onMeasure(w, MeasureSpec.makeMeasureSpec(maxH, MeasureSpec.AT_MOST))
    }
}

class AutoService : AccessibilityService() {

    companion object { @Volatile var instance: AutoService? = null }

    private val prefs by lazy { getSharedPreferences("cfg", MODE_PRIVATE) }
    private val h = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var bubble: FrameLayout
    private lateinit var scroller: MaxHeightScroll
    private val groups = mutableListOf<Triple<TextView, LinearLayout, String>>()
    private var attached = false
    private var bubbleDp = 44

    private val rootLp by lazy {
        LP(WRAP_CONTENT, WRAP_CONTENT, LP.TYPE_ACCESSIBILITY_OVERLAY,
            LP.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("x", dp(8)); y = prefs.getInt("y", dp(160))
        }
    }
    private val markers = mutableListOf<TextView>()
    private lateinit var speedLabel: TextView
    private lateinit var delayLabel: TextView
    private lateinit var sizeLabel: TextView
    private lateinit var speedBar: SeekBar
    private lateinit var modeBtn: Button
    private lateinit var clickBtn: Button

    // state
    private var speed = 5
    private var delayMs = 1000L
    private var multi = false
    private var scrollDir = 0
    private var loopActive = false
    private var stroke: GestureDescription.StrokeDescription? = null
    private var fingerY = 0f
    private var clicking = false
    private var clickIdx = 0

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        bubbleDp = prefs.getInt("bubble", 44)
        buildUi()
        if (prefs.getBoolean("visible", true)) setOverlayVisible(true)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        cleanup(); return super.onUnbind(intent)
    }

    override fun onDestroy() { cleanup(); super.onDestroy() }

    private fun cleanup() {
        instance = null
        stopScroll(); stopClick()
        h.removeCallbacksAndMessages(null)
        markers.forEach { runCatching { wm.removeView(it) } }; markers.clear()
        if (attached) { runCatching { wm.removeView(root) }; attached = false }
    }

    /** Dipanggil dari MainActivity (saklar ON/OFF). */
    fun setOverlayVisible(v: Boolean) {
        prefs.edit().putBoolean("visible", v).apply()
        if (v && !attached) {
            wm.addView(root, rootLp); attached = true
        } else if (!v && attached) {
            stopScroll(); stopClick()
            markers.forEach { runCatching { wm.removeView(it) } }; markers.clear()
            collapseAll(); scroller.visibility = View.GONE
            wm.removeView(root); attached = false
        }
    }

    // ---------------- UI ----------------

    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; textSize = 12f; isAllCaps = false
        minHeight = 0; minimumHeight = 0; minWidth = 0; minimumWidth = 0
        setPadding(dp(4), dp(6), dp(4), dp(6))
        layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
        setOnClickListener { f() }
    }

    private fun holdBtn(t: String, dir: Int) = btn(t) {}.apply {
        setOnClickListener(null)
        setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    v.parent.requestDisallowInterceptTouchEvent(true); startScroll(dir)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> stopScroll()
            }
            true
        }
    }

    private fun row(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        v.forEach { addView(it) }
    }

    private fun label(t: String) = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = 12f
        setPadding(dp(4), dp(6), dp(4), dp(2))
    }

    private fun refresh() { if (attached) wm.updateViewLayout(root, rootLp) }

    private fun collapseAll() {
        groups.forEach { (hd, ct, t) -> ct.visibility = View.GONE; hd.text = "▸ $t" }
    }

    private fun addGroup(menu: LinearLayout, title: String, vararg views: View) {
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE
            views.forEach { addView(it) }
        }
        val head = TextView(this).apply {
            text = "▸ $title"; setTextColor(Color.WHITE); textSize = 14f
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = GradientDrawable().apply {
                setColor(0x33FFFFFF); cornerRadius = dp(8).toFloat()
            }
        }
        head.setOnClickListener {
            val open = content.visibility == View.VISIBLE
            collapseAll()
            if (!open) { content.visibility = View.VISIBLE; head.text = "▾ $title" }
            refresh()
        }
        groups.add(Triple(head, content, title))
        menu.addView(head, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(4) })
        menu.addView(content)
    }

    private fun applyBubbleSize() {
        bubble.layoutParams = LinearLayout.LayoutParams(dp(bubbleDp), dp(bubbleDp))
    }

    private fun resizeBubble(d: Int) {
        bubbleDp = (bubbleDp + d).coerceIn(28, 84)
        prefs.edit().putInt("bubble", bubbleDp).apply()
        sizeLabel.text = "Ukuran bubble: $bubbleDp"
        applyBubbleSize(); refresh()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        // Bubble (logo) — tap = buka/tutup menu, geser = pindah
        bubble = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL; setColor(0xE61565C0.toInt())
                setStroke(dp(2), 0x80FFFFFF.toInt())
            }
            addView(ImageView(context).apply {
                setImageResource(R.drawable.ic_launcher_foreground)
                scaleX = 1.4f; scaleY = 1.4f
            }, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        }
        applyBubbleSize()
        root.addView(bubble)

        val menu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(8))
        }
        scroller = MaxHeightScroll(this, (resources.displayMetrics.heightPixels * 0.55f).toInt()).apply {
            visibility = View.GONE
            background = GradientDrawable().apply {
                setColor(0xE6202124.toInt()); cornerRadius = dp(12).toFloat()
            }
            addView(menu)
        }
        root.addView(scroller, LinearLayout.LayoutParams(dp(210), WRAP_CONTENT).apply { topMargin = dp(4) })

        drag(bubble, root, rootLp, persist = true) {
            scroller.visibility = if (scroller.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            refresh()
        }

        // --- Menu SCROLL ---
        speedLabel = label("Kecepatan: $speed")
        speedBar = SeekBar(this).apply {
            max = 9; progress = speed - 1
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { setSpeed(p + 1) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        addGroup(menu, "Scroll",
            row(btn("▲ Naik") { toggleScroll(-1) }, btn("■ Stop") { stopScroll() }, btn("▼ Turun") { toggleScroll(1) }),
            row(btn("🐢 Pelan") { setSpeed(2) }, btn("🐇 Cepat") { setSpeed(9) }),
            speedLabel, speedBar,
            label("Tahan untuk scroll:"),
            row(holdBtn("Tahan ▲", -1), holdBtn("Tahan ▼", 1)))

        // --- Menu AUTO KLIK ---
        modeBtn = btn("Mode: Single") {
            multi = !multi
            modeBtn.text = if (multi) "Mode: Multi" else "Mode: Single"
        }
        delayLabel = label("Jeda: $delayMs ms")
        clickBtn = btn("▶ Mulai Klik") { if (clicking) stopClick() else startClick() }
        addGroup(menu, "Auto Klik",
            row(modeBtn),
            row(btn("+ Titik") { addMarker() }, btn("− Titik") { removeMarker() }),
            delayLabel,
            row(btn("− Jeda") { stepDelay(false) }, btn("+ Jeda") { stepDelay(true) }),
            row(clickBtn))

        // --- Menu PENGATURAN ---
        sizeLabel = label("Ukuran bubble: $bubbleDp")
        addGroup(menu, "Pengaturan",
            sizeLabel,
            row(btn("− Kecil") { resizeBubble(-6) }, btn("+ Besar") { resizeBubble(6) }),
            row(btn("✕ Matikan overlay") {
                setOverlayVisible(false)
                Toast.makeText(this, "Nyalakan lagi dari aplikasi AutoScroll", Toast.LENGTH_LONG).show()
            }))
    }

    private fun drag(handle: View, target: View, lp: LP, persist: Boolean = false, onTap: (() -> Unit)? = null) {
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val ox = (e.rawX - dx).toInt(); val oy = (e.rawY - dy).toInt()
                    if (abs(ox) > 10 || abs(oy) > 10) moved = true
                    if (moved) { lp.x = sx + ox; lp.y = sy + oy; wm.updateViewLayout(target, lp) }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onTap?.invoke()
                    else if (persist) prefs.edit().putInt("x", lp.x).putInt("y", lp.y).apply()
                }
            }
            true
        }
    }

    // ---------------- Scroll ----------------

    private fun setSpeed(s: Int) {
        speed = s.coerceIn(1, 10)
        speedLabel.text = "Kecepatan: $speed"
        if (speedBar.progress != speed - 1) speedBar.progress = speed - 1
    }

    private fun toggleScroll(dir: Int) { if (scrollDir == dir) stopScroll() else startScroll(dir) }

    private fun startScroll(dir: Int) {
        scrollDir = dir
        if (!loopActive) { loopActive = true; scrollStep() }
    }

    private fun stopScroll() { scrollDir = 0 }

    /** Satu sentuhan jari yang terus bergerak (tanpa diangkat) = scroll halus tanpa fling. */
    private fun scrollStep() {
        if (scrollDir == 0 && stroke == null) { loopActive = false; return }
        val dm = resources.displayMetrics
        val top = dm.heightPixels * 0.2f
        val bottom = dm.heightPixels * 0.8f
        val cx = rootLp.x + (if (root.width > 0) root.width else dp(44)) / 2
        val x = if (cx < dm.widthPixels / 2) dm.widthPixels * 0.85f else dm.widthPixels * 0.15f
        val move = speed * 24f * (if (scrollDir > 0) -1 else 1)
        val prev = stroke
        val path = Path()
        val next: GestureDescription.StrokeDescription
        var end = false
        if (prev == null) {
            fingerY = if (scrollDir > 0) bottom else top
            path.moveTo(x, fingerY); path.lineTo(x, fingerY + move)
            fingerY += move
            next = GestureDescription.StrokeDescription(path, 0, 200, true)
        } else {
            path.moveTo(x, fingerY)
            if (scrollDir == 0 || fingerY + move !in top..bottom) {
                path.lineTo(x, fingerY + 1); end = true
                next = prev.continueStroke(path, 0, 10, false)
            } else {
                path.lineTo(x, fingerY + move); fingerY += move
                next = prev.continueStroke(path, 0, 200, true)
            }
        }
        stroke = if (end) null else next
        dispatchGesture(GestureDescription.Builder().addStroke(next).build(),
            object : GestureResultCallback() {
                override fun onCompleted(g: GestureDescription?) { scrollStep() }
                override fun onCancelled(g: GestureDescription?) {
                    stroke = null
                    h.postDelayed({ scrollStep() }, 100)
                }
            }, null)
    }

    // ---------------- Auto klik ----------------

    private fun addMarker() {
        val dm = resources.displayMetrics
        val tv = TextView(this).apply {
            text = "${markers.size + 1}"; gravity = Gravity.CENTER
            setTextColor(Color.WHITE); textSize = 14f
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL; setColor(0xB3E53935.toInt()); setStroke(dp(2), Color.WHITE)
            }
        }
        val lp = LP(dp(44), dp(44), LP.TYPE_ACCESSIBILITY_OVERLAY,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dm.widthPixels / 2 - dp(22) + markers.size * dp(12)
            y = dm.heightPixels / 2 + markers.size * dp(12)
        }
        tv.tag = lp
        drag(tv, tv, lp)
        wm.addView(tv, lp)
        markers.add(tv)
    }

    private fun removeMarker() {
        if (clicking) return
        markers.removeLastOrNull()?.let { runCatching { wm.removeView(it) } }
    }

    private fun setMarkersTouchable(touchable: Boolean) {
        markers.forEach {
            val lp = it.tag as LP
            lp.flags = if (touchable) lp.flags and LP.FLAG_NOT_TOUCHABLE.inv()
                       else lp.flags or LP.FLAG_NOT_TOUCHABLE
            wm.updateViewLayout(it, lp)
        }
    }

    private fun stepDelay(up: Boolean) {
        val s = if (delayMs < 1000) 100L else 500L
        delayMs = (if (up) delayMs + s else delayMs - s).coerceIn(50L, 60000L)
        delayLabel.text = "Jeda: $delayMs ms"
    }

    private val clickRunnable = object : Runnable {
        override fun run() {
            if (!clicking || markers.isEmpty()) { stopClick(); return }
            val m = if (multi) markers[clickIdx % markers.size] else markers[0]
            clickIdx++
            val loc = IntArray(2)
            m.getLocationOnScreen(loc)
            val p = Path().apply { moveTo(loc[0] + m.width / 2f, loc[1] + m.height / 2f) }
            dispatchGesture(GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(p, 0, 50)).build(), null, null)
            h.postDelayed(this, delayMs)
        }
    }

    private fun startClick() {
        if (markers.isEmpty()) {
            Toast.makeText(this, "Tekan '+ Titik' dulu, geser ke target", Toast.LENGTH_SHORT).show()
            return
        }
        clicking = true; clickIdx = 0
        clickBtn.text = "■ Stop Klik"
        setMarkersTouchable(false)
        h.post(clickRunnable)
    }

    private fun stopClick() {
        if (!clicking) return
        clicking = false
        h.removeCallbacks(clickRunnable)
        if (::clickBtn.isInitialized) clickBtn.text = "▶ Mulai Klik"
        setMarkersTouchable(true)
    }
}
